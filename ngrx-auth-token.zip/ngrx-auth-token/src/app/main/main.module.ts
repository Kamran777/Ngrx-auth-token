// HOME AFTER LOGIN

import { HomeDashboardComponent } from './homeDashboard/homeDashboard.component';
import { HomeComponent } from './home/home.component';

// ERROR

import { ErrorComponent } from './error/error.component';

// GENERAL

import { CommonModule } from '@angular/common';
import { HeaderComponent } from './header/header.component';
import { MainRoutingModule } from './main-routing.module';
import { NgModule } from '@angular/core';

// COMPONENTS

import { MainComponent } from './main/main.component';
import { StartComponent } from './start/start.component';

@NgModule({
  imports: [
    CommonModule,
    MainRoutingModule
  ],
  declarations: [
    ErrorComponent,
    HeaderComponent,
    HomeComponent,
    HomeDashboardComponent,
    MainComponent,
    StartComponent
  ],
  exports: [
    MainComponent,
    StartComponent
  ]
})
export class MainModule { }
