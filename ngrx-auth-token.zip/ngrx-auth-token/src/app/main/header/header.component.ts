import { Router } from '@angular/router';
import { Observable } from "rxjs/Rx";
import { Component, OnInit, Input, EventEmitter, Output } from "@angular/core";

@Component({
  selector: "app-header",
  templateUrl: "./header.component.html",
  styleUrls: ["./header.component.css"],
})
export class HeaderComponent implements OnInit {
  
  @Input("user") user$: Observable<any>;
  @Output() logout: EventEmitter<any> = new EventEmitter(false);

  constructor(public router: Router) {
  }

  ngOnInit() {}

  signOut() {
    this.logout.emit();
  }
}
