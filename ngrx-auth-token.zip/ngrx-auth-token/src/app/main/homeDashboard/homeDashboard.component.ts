import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homeDashboard',
  templateUrl: './homeDashboard.component.html',
  styleUrls: ['./homeDashboard.component.css']
})
export class HomeDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
