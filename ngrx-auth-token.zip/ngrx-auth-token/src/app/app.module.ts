// FIREBASE & AUTH

import { AngularFireModule } from "angularfire2";
import { AuthGuard } from "./auth/guards/auth.guard";
import { AuthModule } from "./auth/auth.module";
import { authReducer } from "./auth/store/auth.reducer";
import { firebaseConfig, authConfig } from "./../environments/firebase-config";

// GENERAL

import { AppRoutingModule } from "./app-routing.module";
import { AppComponent } from "./app.component";
import { BrowserModule } from "@angular/platform-browser";
import { HttpModule } from "@angular/http";
import { MainModule } from "./main/main.module";
import { NgModule } from "@angular/core";
import { StoreModule } from "@ngrx/store";

// ONLY DEV
import { StoreDevtoolsModule } from "@ngrx/store-devtools";
import { StoreLogMonitorModule, useLogMonitor } from "@ngrx/store-log-monitor";

export function instrumentOptions() {
  return {
    monitor: useLogMonitor({ visible: true, position: "right" }),
  };
}
//dev-only END

@NgModule({
  declarations: [AppComponent],
  imports: [
    AppRoutingModule,
    AuthModule,
    BrowserModule,
    HttpModule,
    MainModule,
    AngularFireModule.initializeApp(firebaseConfig, authConfig),
    StoreModule.provideStore({
      auth: authReducer,
    }),
    StoreDevtoolsModule.instrumentStore(instrumentOptions),
    StoreLogMonitorModule,
  ],
  providers: [AuthGuard],
  bootstrap: [AppComponent],
})
export class AppModule {}
