// AUTH

import { AuthEffects } from './store/auth.effects';
import { AuthRoutingModule } from './auth-routing.module';
import { AuthService } from './services/auth.service';

// GENERAL

import { CommonModule } from '@angular/common';
import { EffectsModule } from '@ngrx/effects';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';

// COMPONENTS

import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';

@NgModule({
  imports: [
    AuthRoutingModule,
    CommonModule,
    FormsModule, 
    ReactiveFormsModule,
    EffectsModule.run(AuthEffects)
  ],
  declarations: [
    LoginComponent,
    RegisterComponent
  ],
  providers: [
    AuthService
  ]
})
export class AuthModule { }
