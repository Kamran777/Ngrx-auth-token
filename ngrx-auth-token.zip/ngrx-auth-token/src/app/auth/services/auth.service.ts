import { User } from "./../model/user";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs/Rx";
import { AngularFire, FirebaseAuthState } from "angularfire2";

@Injectable()
export class AuthService {
  constructor(public af: AngularFire) {}

  signIn(user: User): Observable<FirebaseAuthState> {
    return this.fromFirebaseAuthPromise(this.af.auth.login({ ...user }));
  }

  signOut() {
    return this.fromFirebaseAuthPromise(this.af.auth.logout());
  }

  signUp(user: User): Observable<FirebaseAuthState> {
    return this.fromFirebaseAuthPromise(this.af.auth.createUser({ ...user }));
  }

  private fromFirebaseAuthPromise(promise): Observable<any> {
    return Observable.fromPromise(<Promise<any>>promise);
  }
}
