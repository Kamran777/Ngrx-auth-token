export interface AuthState {
  userData: any;
  isLoggedIn: boolean;
  error: any;
}

export const authInitialState: AuthState = {
  userData: null,
  isLoggedIn: false,
  error: null,
};
