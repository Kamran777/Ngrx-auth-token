import { FormGroup } from "@angular/forms";

export class PasswordValidator {
  static matchingPasswords(passwordKey: string, confirmPasswordKey: string) {
    return (
      group: FormGroup
    ): {
      [key: string]: any;
    } => {
      let password = group.controls[passwordKey];
      let confirmPassword = group.controls[confirmPasswordKey];

      if (password.pristine || confirmPassword.pristine) {
        return null;
      }

      group.markAsTouched();

      if (password.value === confirmPassword.value) {
        return null;
      }

      return {
        isValid: false,
      };
    };
  }
}
