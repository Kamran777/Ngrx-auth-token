import { AuthMethods, AuthProviders } from "angularfire2";

export const firebaseConfig = {
  apiKey: "AIzaSyBtLT05SKGnqKzOPA-Kgcg3R-S-0f_52rc",
  authDomain: "auth-token-5b726.firebaseapp.com",
  databaseURL: "https://auth-token-5b726.firebaseio.com",
  projectId: "auth-token-5b726",
  storageBucket: "auth-token-5b726.appspot.com",
  messagingSenderId: "777832652749",
  appId: "1:777832652749:web:f2ba20abf54a511ea82e84",
  measurementId: "G-3C68MW82T7",
};

export const authConfig = {
  provider: AuthProviders.Password,
  method: AuthMethods.Password,
};
